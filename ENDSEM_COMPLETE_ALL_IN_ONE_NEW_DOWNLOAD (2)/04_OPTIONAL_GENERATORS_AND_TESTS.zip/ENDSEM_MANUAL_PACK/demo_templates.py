"""Independent menu-driven Tier C teaching templates, no full pipeline needed."""
PRELUDE='''"""{title}: tiny standalone MENU-DRIVEN lab demo.
Python 3.10+; install pycryptodome. Fixed small parameters are educational only.
Run this file, select 1, then 2 to exit. No file outside this script is required.
"""
import hashlib, hmac, json, math
from Crypto.Cipher import AES, PKCS1_OAEP
from Crypto.PublicKey import RSA
from Crypto.Hash import SHA256
from Crypto.Util.Padding import pad, unpad
LABELS={{'title':'\\n{title}', 'menu':'1 Run demonstration\\n2 Exit', 'prompt':'Input Choice: ',
        'invalid':'Invalid input.', 'output':'Output {{label}}: {{value}}'}}
def out(label,value): print(LABELS['output'].format(label=label,value=value))
'''
FOOTER='''
def main():
    while True:
        print(LABELS['title']); print(LABELS['menu'])
        try:
            choice=input(LABELS['prompt']).strip()
            if choice=='2': return
            if choice=='1': demo()
            else: print(LABELS['invalid'])
        except (ValueError,EOFError,KeyboardInterrupt): return
if __name__=='__main__': main()
'''
DEMOS={
'01_paillier':('PAILLIER ADDITION', '''
def encrypt(m,r):
    n=53*59; return pow(n+1,m,n*n)*pow(r,n,n*n)%(n*n)
def demo():
    n=53*59; lam=math.lcm(52,58); d=lam*pow(lam,-1,n)
    c1,c2=encrypt(1,2),encrypt(1,3); c=c1*c2%(n*n)
    result=(pow(c,d,n*n)-1)//n
    out('encrypted 1 + encrypted 1',[hex(c1),hex(c2)])
    out('encrypted sum',hex(c)); out('decrypted aggregate',result)
    assert result==2; return result
'''),
'02_elgamal_signature':('ELGAMAL SIGNATURE', '''
def demo():
    p,g,x,k=467,2,127,53; y=pow(g,x,p)
    message=b'CandidateID=1;ConstituencyID=101'; m=int.from_bytes(hashlib.sha512(message).digest(),'big')%(p-1)
    r=pow(g,k,p); s=pow(k,-1,p-1)*(m-x*r)%(p-1)
    valid=pow(g,m,p)==pow(y,r,p)*pow(r,s,p)%p
    invalid=pow(g,(m+1)%(p-1),p)!=pow(y,r,p)*pow(r,s,p)%p
    out('signature (r,s)',(r,s)); out('verification',valid); out('tamper rejected',invalid)
    assert valid and invalid; return valid
'''),
'03_schnorr':('SCHNORR SIGNATURE', '''
def challenge(r,data): return int.from_bytes(hashlib.sha256(str(r).encode()+b'|'+data).digest(),'big')%233
def demo():
    p,q,g,x,k=467,233,4,127,53; y=pow(g,x,p); message=b'sample record'
    r=pow(g,k,p); s=(k+challenge(r,message)*x)%q
    valid=pow(g,s,p)==r*pow(y,challenge(r,message),p)%p
    out('signature (r,s)',(r,s)); out('verification',valid)
    assert valid; return valid
'''),
'04_shamir':('SHAMIR 2-OF-3 RECONSTRUCTION', '''
def recover(shares):
    if len(shares)<2 or len(set(x for x,y in shares))!=len(shares): raise ValueError('insufficient distinct shares')
    prime=2089; result=0
    for x,y in shares:
        a=b=1
        for u,v in shares:
            if u!=x: a=a*(-u)%prime; b=b*(x-u)%prime
        result=(result+y*a*pow(b,-1,prime))%prime
    return result
def demo():
    secret=123; shares=[(x,(secret+71*x)%2089) for x in [1,2,3]]
    result=recover([shares[0],shares[2]])
    out('shares',shares); out('temporarily reconstructed secret',result)
    assert result==secret; return result
'''),
'05_sse':('HMAC SEARCH INDEX', '''
def token(field,value): return hmac.new(bytes(range(32)),json.dumps([field,str(value)]).encode(),hashlib.sha256).hexdigest()
def demo():
    index={token('group',101):[1,3],token('group',102):[2]}
    result=index.get(token('group',101),[])
    # Check whole decoded keys, not accidental short hex substrings such as "101".
    assert all(len(k)==64 and k!=str(101) and k!=str(102) for k in index)
    out('stored opaque index',index); out('search for group 101',result)
    assert result==[1,3]; return result
'''),
'06_hybrid':('RSA-OAEP / AES-GCM HYBRID', '''
def demo():
    rsa=RSA.generate(2048); key=bytes(range(32)); nonce=bytes(range(12)); raw=b'sample payload'
    c=AES.new(key,AES.MODE_GCM,nonce=nonce); ct,tag=c.encrypt_and_digest(raw)
    wrapped=PKCS1_OAEP.new(rsa.public_key(),hashAlgo=SHA256).encrypt(key)
    recovered=PKCS1_OAEP.new(rsa,hashAlgo=SHA256).decrypt(wrapped)
    result=AES.new(recovered,AES.MODE_GCM,nonce=nonce).decrypt_and_verify(ct,tag)
    out('AES ciphertext',ct.hex()); out('wrapped key bytes',len(wrapped)); out('round trip',result==raw)
    assert result==raw; return True
'''),
'07_dh':('DIFFIE-HELLMAN AGREEMENT', '''
def demo():
    p,g,a,b=467,2,127,71; A,B=pow(g,a,p),pow(g,b,p)
    first,second=pow(B,a,p),pow(A,b,p)
    key1=hashlib.sha256(str(first).encode()).digest(); key2=hashlib.sha256(str(second).encode()).digest()
    out('public contributions',(A,B)); out('derived keys match',key1==key2)
    out('derived key DEMO ONLY',key1.hex()); assert key1==key2; return True
''')}
def generate():
    import re
    result={}
    for name,(title,body) in DEMOS.items():
        source=PRELUDE.format(title=title)
        source=source[:source.index('LABELS=')]
        labels={'title':'\n'+title,'menu':'1 Run demonstration\n2 Exit','prompt':'Input Choice: ',
                'invalid':'Invalid input.','output':'Output {label}: {value}', 'shares_bad':'Insufficient distinct shares.'}
        for i,label in enumerate(re.findall(r"out\('([^']+)'",body)):
            key='result_'+str(i); labels[key]=label;body=body.replace("out('"+label+"'", "out('"+key+"'")
        body=body.replace("raise ValueError('insufficient distinct shares')", "raise ValueError(LABELS['shares_bad'])")
        zones="\n# QUICK EDIT: change LABELS for wording; change values inside demo() for\n# sample inputs. Keep the math and its matching assert together when editing.\n# ================= ZONE 1: ALL OUTPUT LABELS =================\nLABELS = "+repr(labels)+"\n"
        zones+="# ================= ZONE 2: ROLES =================\n# Single-user primitive exercise; no role menus are needed.\n"
        zones+="# ================= ZONE 3: PARAMETERS =================\n# Small educational parameters are shown beside each primitive formula.\n"
        zones+="# ================= ZONE 4: DEMONSTRATION POLICY =================\n# Fixed examples only; use the full answers for DEMO/REAL and RBAC flags.\n"
        zones+="# ================= ZONE 5: MENU =================\nMENU_ACTIONS = {'1':'demo', '2':None}\n"
        zones+="# ================= ZONE 6: PRIMITIVE =================\n"+body
        zones+="# ================= ZONE 7: DISPLAY / MAIN =================\ndef out(label,value): print(LABELS['output'].format(label=LABELS[label],value=value))\n"
        footer=FOOTER.replace("if choice=='2': return\n            if choice=='1': demo()", "if choice in MENU_ACTIONS and MENU_ACTIONS[choice] is None: return\n            if choice in MENU_ACTIONS: globals()[MENU_ACTIONS[choice]]()")
        result[name+'.py']=source+zones+footer
    return result
