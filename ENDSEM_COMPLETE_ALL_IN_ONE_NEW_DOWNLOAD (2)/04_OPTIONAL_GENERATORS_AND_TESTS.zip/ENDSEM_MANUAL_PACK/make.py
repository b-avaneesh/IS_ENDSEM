"""Tier B: generate a complete standalone file for any supported valid combination."""
import argparse
from pathlib import Path
from engine import AXES,DEFAULT,configuration,render

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key,values in AXES.items(): p.add_argument('--'+key,choices=values,default=DEFAULT[key])
    p.add_argument('--list',action='store_true');p.add_argument('--output',default='generated_answer.py')
    args=vars(p.parse_args()); listing=args.pop('list'); path=Path(args.pop('output'))
    if listing:
        for k,v in AXES.items(): print(k+': '+', '.join(v))
        print('Constraints: DSA/ECDSA require SHA256/SHA512/SHA3-256; multiplicative HE requires --tally product.\nAuction ONE_HOT means counts per enumerated bid value. --time system/ask requires a matching demo window or DEMO_MODE=False.')
        return
    try: code=render(**args)
    except ValueError as e: p.error(str(e))
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(code,encoding='utf-8');print(path)
if __name__=='__main__': main()
