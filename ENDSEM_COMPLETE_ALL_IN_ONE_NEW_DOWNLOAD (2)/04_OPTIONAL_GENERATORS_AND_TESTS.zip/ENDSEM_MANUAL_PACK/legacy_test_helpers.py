"""Executable coverage: every shipped Tier A/C, 200 random Tier B, every axis/skin.
Uses isolated temp state and cached test key generation. --fast reduces only RSA transport
from 4096 to 2048; the independent golden session ALWAYS uses actual RSA-4096.
No original full paper transcript was supplied: golden session compares a labelled local
output contract plus independent supplied cryptographic vectors, not a paper transcript.
"""
import argparse,contextlib,copy,csv,importlib.util,io,json,random,tempfile,traceback,sys,time,hashlib
from pathlib import Path
from unittest.mock import patch
from Crypto.PublicKey import RSA,DSA
from engine import ROOT,AXES,DEFAULT,render,valid
from build_all import FIELDS

RESULTS=[]; RSA_CACHE={}; DSA_CACHE={}; ORIGINAL_DSA=DSA.generate

def cached_dsa(bits,randfunc=None,**kwargs):
    label=getattr(randfunc,'label','random'); key=(bits,label)
    if key not in DSA_CACHE: DSA_CACHE[key]=ORIGINAL_DSA(bits,randfunc=randfunc,**kwargs).export_key(format='DER')
    return DSA.import_key(DSA_CACHE[key])
def cached_rsa(m,label,bits):
    key=(bits,label)
    if key not in RSA_CACHE: RSA_CACHE[key]=RSA.generate(bits,randfunc=m.rng(label)).export_key()
    return RSA.import_key(RSA_CACHE[key])
def module(code):
    import types
    m=types.ModuleType('answer');m.__file__=str(ROOT/'test_answer.py');exec(compile(code,m.__file__,'exec'),m.__dict__);return m

def action(m,name,role,inputs=()):
    m.ROLE=role
    with patch('builtins.input',side_effect=list(inputs)): return getattr(m,name)()
def rejected(call,expected=None):
    try: call()
    except (ValueError,TypeError,KeyError,IndexError) as error:
        if expected is not None: assert str(error)==expected,(str(error),expected)
        return
    raise AssertionError('Operation unexpectedly accepted')
def rebind(m,record):
    p=record['packet'];p.pop('envelope_signature',None)
    p['envelope_signature']=m.sign(m.digest(m.canonical(p)),record['owner'],p['id']+100)
    record['timestamp'],record['tsa_signature']=m.stamp(p,m.datetime.fromisoformat(record['timestamp']['time']))

def exercise(code,fast=True,negative=True):
    m=module(code);m.FAST=fast
    with tempfile.TemporaryDirectory(prefix='endsem-test-') as folder,contextlib.redirect_stdout(io.StringIO()) as output,patch.object(DSA,'generate',cached_dsa):
        m.DATA_DIR=Path(folder);m.rsa_key=lambda label,bits:cached_rsa(m,label,bits)
        m.setup(); users=list(m.GROUPS); start=m.datetime.fromisoformat(m.PUBLIC['start']);end=m.datetime.fromisoformat(m.PUBLIC['end'])
        # A system-clock configuration must have a matching explicit demonstration window.
        if m.TIME_SOURCE=='system':
            now=m.datetime.now(m.IST);m.PUBLIC['start']=(now-m.timedelta(minutes=5)).isoformat();m.PUBLIC['end']=(now+m.timedelta(hours=1)).isoformat();m.store(m.DATA_DIR/'public.json',m.PUBLIC)
        def cast_inputs(i,value):
            answers=[users[i],str(value),str(m.GROUPS[users[i]])]
            if m.TIME_SOURCE=='ask':answers.append((start+m.timedelta(minutes=i)).strftime(m.FORMAT))
            return answers
        second=2 if m.TALLY_MODE!='SAMPLE_COMPAT' else 1
        # Exercise the actual nested menus, including invalid menu input, Back and Exit.
        session=['bad','1','1']+cast_inputs(0,1)+['1']+cast_inputs(1,second)+['2','2','1','1','1','2','2','1',str(m.GROUPS[users[0]]),'3','3','1','1 2','2','1 2','123','123','3','4']
        with patch('builtins.input',side_effect=session):m.main()
        assert len(m.STATE['records'])==2 and all(r['verified'] for r in m.STATE['records'].values()),output.getvalue()
        expected=[1,1]+[0]*(len(m.VALUES)-2) if m.TALLY_MODE=='ONE_HOT' else [2]
        assert action(m,'decrypt_total','tally',['1 2','123','123'])==expected
        assert action(m,'search','server',['1',str(m.GROUPS[users[0]])])==[1]
        assert action(m,'search','server',['2',m.datetime.fromisoformat(m.PUBLIC['start']).strftime(m.FORMAT),m.datetime.fromisoformat(m.PUBLIC['end']).strftime(m.FORMAT)])==[1,2]
        for r in m.STATE['records'].values(): assert m.validate(r)
        index=m.canonical(m.STATE['index']);assert b'ConstituencyID' not in index and b'03-11-2025' not in index
        assert all(k!=str(m.GROUPS[u]) for u in users for k in m.STATE['index'])
        assert all(len(k)>=32 and all(c in '0123456789abcdef' for c in k) for k in m.STATE['index'])
        saved=copy.deepcopy(m.STATE); m.STATE={};m.setup();assert m.STATE==saved
        if negative:
            rejected(lambda:action(m,'cast','server'),m.TEXT['denied'])
            rejected(lambda:action(m,'decrypt_total','tally',['1']),m.TEXT['quorum'])
            rejected(lambda:action(m,'decrypt_total','tally',['1 2','wrong']),m.TEXT['quorum'])
            rejected(lambda:action(m,'decrypt_total','client'),m.TEXT['denied'])
            # Seal prevents a stored aggregate being substituted with an individual ciphertext.
            m.STATE['aggregate']['ciphertexts']=copy.deepcopy(m.STATE['records'][1]['packet']['he'])
            rejected(lambda:action(m,'decrypt_total','tally',['1 2']),m.TEXT['bad_share']);m.STATE=copy.deepcopy(saved)
            m.STATE['aggregate']=None
            rejected(lambda:action(m,'aggregate','tally',['1']),m.TEXT['invalid_ids'])
            rejected(lambda:action(m,'decrypt_total','tally'),m.TEXT['no_total'])
            rejected(lambda:action(m,'cast','client',cast_inputs(0,1)),m.TEXT['duplicate'])
            # Unsigned mutation should fail the authenticated envelope first.
            r=copy.deepcopy(saved['records'][1]);ct=bytearray.fromhex(r['packet']['ct']);ct[0]^=1;r['packet']['ct']=ct.hex();rejected(lambda:m.validate(r))
            r=copy.deepcopy(saved['records'][1]);s=r['packet']['signature'];r['packet']['signature']=[1,1] if isinstance(s,list) else '00'* (len(s)//2);rebind(m,r)
            rejected(lambda:m.validate(r),m.TEXT['sig_bad'])
            # Deliberately re-sign a validly encrypted changed payload, retaining original hash.
            r=copy.deepcopy(saved['records'][1]);p=r['packet'];key=m.unwrap_key(bytes.fromhex(p['wrapped']))
            altered=';'.join(f'{k}={v}' for k,v in zip(m.TEXT['fields'],[2,m.GROUPS[users[0]]])).encode()
            p['ct']=m.seal(altered,key,bytes.fromhex(p['iv'])).hex();rebind(m,r)
            rejected(lambda:m.validate(r),m.TEXT['hash_bad'])
            m.DEMO_LATE=True;action(m,'cast','client',cast_inputs(2,1));rejected(lambda:m.validate(m.STATE['records'][3]),m.TEXT['late']);m.DEMO_LATE=False
            m.STATE=copy.deepcopy(saved);m.save()
        return output.getvalue(),m

def run_case(label,code,fast,group='tier_b'):
    try:
        output,m=exercise(code,fast=fast)
        RESULTS.append({'case':label,'group':group,'status':'PASS'});return True,output
    except Exception as e:
        RESULTS.append({'case':label,'group':group,'status':'FAIL','error':str(e),'traceback':traceback.format_exc()});return False,''

def golden():
    out,m=exercise(render(),fast=False,negative=False)
    RESULTS.append({'case':'golden_actual_RSA4096','group':'golden','status':'PASS'})
    required=[
      'a2152f5e30dee0d9be483e7ed69a634eaba168e7757fd9d46f8ba7a1236a87125d12b4e6c824a2c7f777dd929e295296854fff55ed4c71b9d84c6b69e0c54ed4',
      '4121092f966fccd24056ffef559c668d96af053bc61a96bd615e12f6ebbfce506e8e90f25c264c6ee1b72a528e7f4626a1afbde8b65588c48bf41895420c8cfd',
      '716234bfd0fc5ca9e28d61a9661c5ff97012daf5d446bdc348bfcd5fe15bc945e4d185a79dd7fff5dd6bc'.replace('fff5','ff77f5'),
      '3969ec08823f99f130ca97508b5447fa0b253d876a71c6b00283d185f3b29bcef2655cef3eb4321835c62e3319bd9e20',
      '0x734302','0x7c14a7','0x10fe4f','Output decrypted aggregate: 2']
    # Independent constant from the supplied AES vector, not derived from code under test.
    required[2]='716234bfd0fc5ca9e28d61a9661c5ff97012daf5d446bdc348bfcd5fe15bc945e4d185a79dd7fff65eb0ffb77f5dd6bc'
    for v in required: assert v in out,v
    (ROOT/'tests/golden_actual_output.txt').write_text(out)
    # The contract is intentionally labelled ours, because the photo has no full sample I/O.
    actual=[s for s in out.splitlines() if s.startswith('Output ') and not any(x in s for x in ['wrapped payload key',' signature:','partial(s)'])]
    contract=ROOT/'tests/golden_expected_contract.txt'
    assert contract.exists(),'Missing local expected output contract; it must be reviewed before testing.'
    assert actual==contract.read_text().splitlines(),'Local output contract changed'

def combinations():
    randomizer=random.Random(3141);chosen=[];seen=set()
    while len(chosen)<200:
        c={k:randomizer.choice(v) for k,v in AXES.items()}
        if not valid(c)[0]:continue
        key=json.dumps(c,sort_keys=True)
        if key not in seen:chosen.append(c);seen.add(key)
    for skin in AXES['skin']:
        for axis,values in AXES.items():
            if axis=='skin':continue
            for value in values:
                c=DEFAULT|{'skin':skin,axis:value}
                if axis=='he' and value!='paillier':c['tally']='product'
                if axis=='tally' and value=='product':c['he']='elgamal'
                key=json.dumps(c,sort_keys=True)
                if key not in seen:chosen.append(c);seen.add(key)
    return chosen

def editability(fast):
    from cookbook_edits import edits,exercise_edit
    base=render();other=render(skin='auction')
    def remove_zones(code):return code.split('# ================= ZONE 1')[0]+code.split('# ================= ZONE 3')[1]
    assert remove_zones(base)==remove_zones(other),'Skin diff escaped Zones 1/2'
    RESULTS.append({'case':'skin_diff_only_zones_1_2','group':'editability','status':'PASS'})
    for name,edit in edits().items():
        try:exercise_edit(name,edit(base),fast);RESULTS.append({'case':name,'group':'editability','status':'PASS'})
        except Exception as e:RESULTS.append({'case':name,'group':'editability','status':'FAIL','error':str(e),'traceback':traceback.format_exc()})

def main():
    p=argparse.ArgumentParser();p.add_argument('--fast',action='store_true');p.add_argument('--quick',action='store_true');args=p.parse_args();start=time.time()
    (ROOT/'tests').mkdir(exist_ok=True)
    golden(); print('Golden RSA-4096 vectors/session passed',flush=True)
    rows=list(csv.DictReader((ROOT/'MANIFEST.csv').open()))
    for i,row in enumerate(rows if not args.quick else rows[:8]):
        okay,_=run_case(row['path'],(ROOT/row['path']).read_text(),args.fast,'tier_a');row['test_result']='PASS' if okay else 'FAIL'
        if i%45==0:print(f'Tier A {i+1}/{len(rows)}; failures={sum(r["status"]=="FAIL" for r in RESULTS)}',flush=True)
    if not args.quick:
        with (ROOT/'MANIFEST.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
    combos=combinations()
    for i,c in enumerate(combos if not args.quick else combos[:8]):
        label=json.dumps(c,sort_keys=True);run_case(label,render(**c),args.fast,'tier_b')
        if i%50==0:print(f'Tier B {i+1}/{len(combos)}; failures={sum(r["status"]=="FAIL" for r in RESULTS)}',flush=True)
    for path in sorted((ROOT/'primitive_demos').glob('*.py')):
        try:
            m=module(path.read_text())
            with contextlib.redirect_stdout(io.StringIO()),patch('builtins.input',side_effect=['invalid','1','2']):m.main()
            RESULTS.append({'case':path.name,'group':'tier_c','status':'PASS'})
        except Exception as e:RESULTS.append({'case':path.name,'group':'tier_c','status':'FAIL','error':str(e)})
    editability(args.fast)
    summary={'elapsed_seconds':round(time.time()-start,2),'fast_RSA2048_matrix':args.fast,'golden_RSA4096':True,'quick':args.quick,'passed':sum(r['status']=='PASS' for r in RESULTS),'failed':sum(r['status']=='FAIL' for r in RESULTS),'groups':{g:sum(r['group']==g for r in RESULTS) for g in sorted({r['group'] for r in RESULTS})},'results':RESULTS,'tier_b_configurations':combos if not args.quick else combos[:8]}
    (ROOT/'tests/results.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:v for k,v in summary.items() if k not in ['results','tier_b_configurations']},indent=2))
    for r in RESULTS:
        if r['status']=='FAIL': print(r)
    return int(summary['failed']>0)
if __name__=='__main__':sys.exit(main())
