"""Pre-exam key setup for one selected standalone answer."""
import argparse,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('file',nargs='?',default='Sample_QP_Answer.py');p.add_argument('--fast',action='store_true');args=p.parse_args()
path=Path(args.file).resolve()
if not path.is_file():p.error('Choose an existing generated answer file.')
raise SystemExit(subprocess.call([sys.executable,str(path),'--keygen']+(['--fast'] if args.fast else [])))
