"""Run every generated endsem program, adapter/skin matrix, 200 random configs,
primitive demos, golden vectors and cookbook edits. Optional process workers.
Test acceleration caches key generation/imports; crypto operations still execute.
DEMO matrix uses --fast RSA2048. Golden/default uses actual RSA4096.
"""
import argparse,ast,contextlib,csv,hashlib,io,json,multiprocessing,time,traceback
from pathlib import Path
from Crypto.PublicKey import RSA,DSA
import legacy_test_helpers as helper
from legacy_test_helpers import module,exercise,action,rejected,cached_rsa,cached_dsa,rebind
from engine import ROOT,render
from build_all import FIELDS
IMPORT_RSA=RSA.import_key;IMPORT_CACHE={};PRIME_CACHE={}
def cached_import(data,*args,**kwargs):
    if args or kwargs:return IMPORT_RSA(data,*args,**kwargs)
    key=data.encode() if isinstance(data,str) else bytes(data)
    if key not in IMPORT_CACHE:IMPORT_CACHE[key]=IMPORT_RSA(data)
    return IMPORT_CACHE[key]
def init_worker():
    RSA.import_key=cached_import
    original_module=helper.module
    def cached_module(code):
        m=original_module(code);original=m.getPrime
        def prime(bits,randfunc=None):
            label=getattr(randfunc,'label',None)
            if label is None:return original(bits,randfunc=randfunc)
            index=getattr(randfunc,'prime_index',0);randfunc.prime_index=index+1;key=(bits,label,index)
            if key not in PRIME_CACHE:PRIME_CACHE[key]=original(bits,randfunc=randfunc)
            return PRIME_CACHE[key]
        m.getPrime=prime;return m
    helper.module=cached_module

def case(job):
    label,config,path=job;t=time.time()
    try:
        code=(ROOT/path).read_text() if path else render(**config)
        ast.parse(code);helper.exercise(code,fast=True,negative=True)
        return {'case':label,'status':'PASS','seconds':round(time.time()-t,3)}
    except Exception:return {'case':label,'status':'FAIL','error':traceback.format_exc()}
def main():
    p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=4);p.add_argument('--quick',action='store_true');args=p.parse_args();start=time.time()
    rows=list(csv.DictReader((ROOT/'MANIFEST.csv').open()));jobs=[(r['path'],None,r['path']) for r in rows]
    extras=helper.combinations();jobs += [(f'generated_{i}',c,None) for i,c in enumerate(extras)]
    if args.quick:jobs=jobs[:2]+jobs[len(rows):len(rows)+3]
    results=[];(ROOT/'tests').mkdir(exist_ok=True)
    with multiprocessing.Pool(args.workers,initializer=init_worker) as pool:
        for i,result in enumerate(pool.imap_unordered(case,jobs,chunksize=8),1):
            results.append(result)
            if i%100==0 or result['status']=='FAIL':
                print(i,'/',len(jobs),'failures',sum(r['status']=='FAIL' for r in results),flush=True)
                (ROOT/'tests/progress.json').write_text(json.dumps(results,indent=2))
    init_worker()
    try:helper.golden()
    except Exception:helper.RESULTS.append(dict(case='golden',status='FAIL',error=traceback.format_exc()))
    for path in sorted((ROOT/'primitive_demos').glob('*.py')):
        try:
            m=module(path.read_text())
            from unittest.mock import patch
            with contextlib.redirect_stdout(io.StringIO()),patch('builtins.input',side_effect=['invalid','1','2']):m.main()
            results.append(dict(case=str(path.relative_to(ROOT)),status='PASS'))
        except Exception:results.append(dict(case=str(path.relative_to(ROOT)),status='FAIL',error=traceback.format_exc()))
    helper.editability(True);results+=helper.RESULTS
    if not args.quick:
        status={r['case']:r['status'] for r in results}
        for r in rows:r['test_result']=status[r['path']]
        with (ROOT/'MANIFEST.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
    report=dict(elapsed_seconds=round(time.time()-start,2),quick=args.quick,generated_variants=len(rows),additional_generated_configs=len(extras),matrix_RSA_bits=2048,golden_RSA_bits=4096,passed=sum(r['status']=='PASS' for r in results),failed=sum(r['status']=='FAIL' for r in results),results=results,extra_configurations=extras)
    (ROOT/'tests/endsem_results.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k not in ('results','extra_configurations')},flush=True)
    for r in results:
        if r['status']=='FAIL':print(r,flush=True)
    return bool(report['failed'])
if __name__=='__main__':raise SystemExit(main())
