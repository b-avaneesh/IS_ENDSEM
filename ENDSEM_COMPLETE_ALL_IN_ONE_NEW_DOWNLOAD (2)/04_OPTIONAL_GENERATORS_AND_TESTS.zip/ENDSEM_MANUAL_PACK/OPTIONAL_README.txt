Run python build_all.py, then python generate_operation_variants.py. Run python test_operation_variants.py for the new operations.
