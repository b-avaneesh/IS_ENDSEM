"""Additional real-process, REAL-mode and non-default quorum checks."""
import sys,json,tempfile,subprocess,contextlib,io,copy
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from engine import ROOT,render
import test_all as t
results=[]
session='\n'.join(['1','1','voter1','1','101','1','voter2','1','102','2','2','1','1','1','2','2','1','101','3','3','1','1 2','2','1 2','123','123','3','4'])+'\n'
with tempfile.TemporaryDirectory() as folder:
    file=Path(folder)/'answer.py';file.write_text(render())
    keygen=subprocess.run([sys.executable,str(file),'--keygen'],text=True,capture_output=True,timeout=180)
    assert keygen.returncode==0 and 'Generating and caching' in keygen.stdout,keygen.stderr
    first=subprocess.run([sys.executable,str(file)],input=session,text=True,capture_output=True,timeout=60)
    assert first.returncode==0 and 'Output decrypted aggregate: 2' in first.stdout and 'Generating and caching' not in first.stdout,first.stdout+first.stderr
    second=subprocess.run([sys.executable,str(file)],input='3\n2\n1 2\n123\n123\n3\n4\n',text=True,capture_output=True,timeout=60)
    assert second.returncode==0 and 'Output decrypted aggregate: 2' in second.stdout and 'Generating and caching' not in second.stdout,second.stdout+second.stderr
    results.append({'case':'actual_separate_process_keygen_and_persistent_reopen_RSA4096','status':'PASS'})
    real=Path(folder)/'real.py';real.write_text(render().replace('DEMO_MODE = True','DEMO_MODE = False'))
    run=subprocess.run([sys.executable,str(real)],input=session,text=True,capture_output=True,timeout=240)
    assert run.returncode==0 and 'Mode=REAL' in run.stdout and 'Output decrypted aggregate: 2' in run.stdout,run.stdout+run.stderr
    public=json.loads(real.with_suffix('').joinpath('public.json').read_text());assert public['he']['n'].bit_length()>=2047
    results.append({'case':'REAL_mode_random_RSA4096_2048bit_HE_current_time_full_menu','status':'PASS'})
# Genuine 2-of-3: use both alternate pairs, then reject insufficient/duplicate IDs.
for he in ('paillier','elgamal','rsa'):
    code=render(he=he,tally='sample' if he=='paillier' else 'product',threshold='shamir').replace('AUTHORITIES = 2','AUTHORITIES = 3')
    m=t.module(code);m.FAST=True
    with tempfile.TemporaryDirectory() as folder,contextlib.redirect_stdout(io.StringIO()):
        m.DATA_DIR=Path(folder);m.rsa_key=lambda label,bits:t.cached_rsa(m,label,bits);m.setup()
        for i in range(2):t.action(m,'cast','client',[f'voter{i+1}','1' if he=='paillier' else str(i+1),str(101+i)]);t.action(m,'check','server',[str(i+1)])
        t.action(m,'aggregate','tally',['1 2'])
        for owners in ('1 3','2 3'):assert t.action(m,'decrypt_total','tally',[owners,'123','123'])==[2]
        for owners in ('1','1 1','1 4'):t.rejected(lambda:t.action(m,'decrypt_total','tally',[owners]),m.TEXT['quorum'])
    results.append({'case':f'{he}_shamir_alternate_pairs_and_invalid_quorums','status':'PASS'})
(ROOT/'tests/supplemental_results.json').write_text(json.dumps(results,indent=2));print(json.dumps(results,indent=2))
