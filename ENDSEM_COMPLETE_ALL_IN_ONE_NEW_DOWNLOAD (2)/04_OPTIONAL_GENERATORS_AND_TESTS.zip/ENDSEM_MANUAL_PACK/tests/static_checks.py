"""Recheck syntax, architecture, every skin diff, and generator CLI validation."""
import sys,ast,csv,json,subprocess,tempfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT))
from engine import render,SKINS
checks=[]
files=list((ROOT/'tier_a').rglob('*.py'))+list((ROOT/'primitive_demos').glob('*.py'))
for path in files:ast.parse(path.read_text())
checks.append({'case':'all_7000_endsem_and_primitive_files_syntax','status':'PASS'})
base=render()
def invariant(text):return text.split('# ================= ZONE 1')[0]+text.split('# ================= ZONE 3')[1]
for skin in SKINS:assert invariant(base)==invariant(render(skin=skin))
checks.append({'case':'all_9_skin_diffs_confined_to_zones_1_2','status':'PASS'})
for p in (ROOT/'tier_a').rglob('*.py'):
    s=p.read_text();core=s.split('# ================= ZONE 7')[1]
    assert all(w not in core.lower() for w in ['voter','candidate','constituency','ballot','auction','bidder'])
    for n in ast.walk(ast.parse(s)):
        if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id in ['print','input']:
            assert isinstance(n.args[0],ast.Call) and isinstance(n.args[0].func,ast.Attribute) and n.args[0].func.attr=='format',ast.dump(n)
checks.append({'case':'all_6993_generic_pipeline_and_dictionary_print_input','status':'PASS'})
with tempfile.TemporaryDirectory() as folder:
    out=Path(folder)/'auction.py'
    command=[sys.executable,str(ROOT/'make.py'),'--skin','auction','--cipher','aes128_ctr','--keywrap','rsa2048','--hash','sha256','--sig','schnorr','--he','paillier','--tally','onehot','--threshold','shamir','--sse','hmac','--storage','sqlite','--output',str(out)]
    run=subprocess.run(command,capture_output=True,text=True);assert run.returncode==0,run.stderr;ast.parse(out.read_text())
    for options in [['--he','elgamal'],['--he','paillier','--tally','product'],['--sig','ecdsa','--hash','md5']]:
        invalid=Path(folder)/'invalid.py'
        run=subprocess.run([sys.executable,str(ROOT/'make.py'),*options,'--output',str(invalid)],capture_output=True,text=True)
        assert run.returncode!=0 and not invalid.exists()
checks.append({'case':'requested_make_CLI_and_invalid_combinations','status':'PASS'})
(ROOT/'tests/static_results.json').write_text(json.dumps(checks,indent=2));print(json.dumps(checks,indent=2))
