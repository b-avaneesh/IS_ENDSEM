"""Actual separate-process grant-paper session, restart, tamper and REAL mode."""
import json,subprocess,sys,tempfile,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/'Grant_Expense_Portal_Answer.py'
SESSION='\n'.join(['1','1','G001','Lab equipment','500','1','G002','Field travel','700','2','3','2','1','G001','2','G002','3','G001','3','G002','4','3','1','G001, G002','2','3','4'])+'\n'
results=[]
with tempfile.TemporaryDirectory() as folder:
 file=Path(folder)/'grant.py';file.write_bytes(SOURCE.read_bytes())
 def invoke(source,input_data):
  r=subprocess.run([sys.executable,str(source)],input=input_data,text=True,capture_output=True,timeout=180)
  assert r.returncode==0,r.stderr;return r.stdout
 output=invoke(file,SESSION)
 for text in ['G001 submitted and stored','G002 submitted and stored','Record found: G002','4c61622065717569706d656e74','4669656c642074726176656c','aggregate decrypted = 1200','Individual amounts not decrypted']:
  assert text in output,text
 state=file.with_suffix('')
 stored=(state/'records.json').read_bytes();assert b'Lab equipment' not in stored and b'Field travel' not in stored
 assert 'amount' not in json.loads(stored)['records']['G001']
 assert (state/'keys/client/signing.json').exists() and (state/'keys/review/description.json').exists() and (state/'keys/finance/paillier.json').exists()
 results.append('actual_separate_process_sample_500_plus_700: PASS')
 replay=invoke(file,'1\n2\n3\n2\n1\nG001\n4\n4\n')
 assert 'Generating separate' not in replay and 'G001 | CT:' in replay and 'G002 | CT:' in replay
 assert 'signature valid' in replay
 results.append('restart_persists_both_records_and_keys: PASS')
 damaged=json.loads(stored);damaged['records']['G001']['ct']='00'+damaged['records']['G001']['ct'][2:]
 (state/'records.json').write_text(json.dumps(damaged))
 rejection=invoke(file,'2\n1\nG001\n4\n4\n')
 assert 'Rejected: Record hash mismatch.' in rejection and 'signature valid' not in rejection
 results.append('stored_ciphertext_tamper_rejected: PASS')
 real=Path(folder)/'real.py';real.write_text(SOURCE.read_text().replace('DEMO_MODE=True','DEMO_MODE=False'))
 actual=invoke(real,SESSION);assert 'aggregate decrypted = 1200' in actual
 public=json.loads((real.with_suffix('')/'public.json').read_text());assert public['he']['n'].bit_length()>=2047
 results.append('REAL_random_2048bit_Paillier_mode: PASS')
ROOT.joinpath('structured_records/sample_acceptance_result.json').write_text(json.dumps(results,indent=2))
print('\n'.join(results))
