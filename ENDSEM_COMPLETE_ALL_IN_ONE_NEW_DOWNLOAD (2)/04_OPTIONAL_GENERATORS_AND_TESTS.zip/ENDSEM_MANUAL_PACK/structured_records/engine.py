"""Structured confidential-text + encrypted-numeric-aggregate endsem family.
Generated answers are standalone: no dependency on this generator at run time.
"""
import itertools,json,pprint
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SKINS={
 'grant':('SECURE GRANT EXPENSE PORTAL','Researcher','Reviewer','Finance Officer','Grant ID','Grant Description','Grant Amount','grant'),
 'reimbursement':('EMPLOYEE REIMBURSEMENT PORTAL','Employee','Auditor','Accounts Officer','Claim ID','Expense Description','Claim Amount','claim'),
 'invoice':('CONFIDENTIAL INVOICE PORTAL','Vendor','Verifier','Finance Officer','Invoice ID','Item Description','Invoice Amount','invoice'),
 'procurement':('SECURE PROCUREMENT PORTAL','Requester','Procurement Reviewer','Budget Officer','Purchase ID','Purchase Description','Purchase Amount','purchase'),
 'medical':('HOSPITAL BILLING PORTAL','Clinic','Medical Auditor','Billing Officer','Bill ID','Service Description','Bill Amount','bill'),
 'payroll':('SECURE PAYROLL PORTAL','HR Officer','Payroll Reviewer','Finance Officer','Pay ID','Role Description','Pay Amount','pay record'),
 'travel':('TRAVEL EXPENSE PORTAL','Traveler','Expense Reviewer','Finance Officer','Trip ID','Travel Description','Travel Amount','trip'),
 'donation':('DONATION EXPENSE PORTAL','Coordinator','Verifier','Treasurer','Donation ID','Purpose Description','Donation Amount','donation')}
CIPHERS=[f'{family}_{mode}' for family in ['aes192','aes128','aes256','des','3des'] for mode in ('cbc','ecb','cfb','ofb','ctr')]
HASHES=('md5','sha1','sha256','sha512','sha3_256')
SIGNATURES=('rsa_v15','rsa_pss','elgamal','schnorr','dsa','ecdsa')
DEFAULT={'skin':'grant','cipher':'aes192_cbc','hash':'md5','sig':'rsa_v15','storage':'json','index':'hmac'}
def valid(c):return not(c['sig'] in ('dsa','ecdsa') and c['hash'] in ('md5','sha1'))
def config(**opts):
 c=DEFAULT|opts
 for axis,values in {'skin':SKINS,'cipher':CIPHERS,'hash':HASHES,'sig':SIGNATURES,'storage':('json','sqlite'),'index':('hmac','siv')}.items():
  if c[axis] not in values:raise ValueError(f'Unsupported {axis}: {c[axis]}')
 if not valid(c):raise ValueError('DSA/ECDSA require SHA256/SHA512/SHA3-256.')
 return c

def render(**opts):
 c=config(**opts)
 code=(ROOT/'template.py.txt').read_text()
 story=dict(zip(('title','client','server','finance','id','description','amount','record'),SKINS[c['skin']]))
 options=dict(story=story,cipher=c['cipher'],hash=c['hash'],sig=c['sig'],storage=c['storage'],index=c['index'])
 return code.replace('@@CONFIG@@',pprint.pformat(options,width=110,sort_dicts=False))

def all_core():
 for skin,cipher,hash_name,sig in itertools.product(SKINS,CIPHERS,HASHES,SIGNATURES):
  config_values=dict(skin=skin,cipher=cipher,hash=hash_name,sig=sig)
  if valid(DEFAULT|config_values):yield config_values
