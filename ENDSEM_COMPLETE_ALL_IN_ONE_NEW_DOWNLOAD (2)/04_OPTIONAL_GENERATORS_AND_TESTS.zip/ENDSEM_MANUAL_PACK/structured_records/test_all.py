"""All standalone variants: encryption, signatures, storage, tamper and RBAC."""
import ast,contextlib,csv,hashlib,io,json,multiprocessing,sys,tempfile,time,traceback,types,copy
from pathlib import Path
from unittest.mock import patch
from Crypto.PublicKey import RSA,DSA
from engine import ROOT
from build_all import FIELDS
_ORIGINAL_RSA_GENERATE=RSA.generate;_ORIGINAL_RSA_IMPORT=RSA.import_key;_ORIGINAL_DSA_GENERATE=DSA.generate
_RSA_KEYS={};_RSA_IMPORTS={};_DSA_KEYS={}
def init():
 def generate(bits,randfunc=None,**kw):
  label=getattr(randfunc,'label',None)
  if label is None:return _ORIGINAL_RSA_GENERATE(bits,randfunc=randfunc,**kw)
  k=(bits,label)
  if k not in _RSA_KEYS:_RSA_KEYS[k]=_ORIGINAL_RSA_GENERATE(bits,randfunc=randfunc,**kw)
  return _RSA_KEYS[k]
 def import_key(raw,**kw):
  if kw:return _ORIGINAL_RSA_IMPORT(raw,**kw)
  key=raw.encode() if isinstance(raw,str) else bytes(raw)
  if key not in _RSA_IMPORTS:_RSA_IMPORTS[key]=_ORIGINAL_RSA_IMPORT(raw)
  return _RSA_IMPORTS[key]
 def dsa_generate(bits,randfunc=None,**kw):
  label=getattr(randfunc,'label',None)
  if label is None:return _ORIGINAL_DSA_GENERATE(bits,randfunc=randfunc,**kw)
  k=(bits,label)
  if k not in _DSA_KEYS:_DSA_KEYS[k]=_ORIGINAL_DSA_GENERATE(bits,randfunc=randfunc,**kw)
  return _DSA_KEYS[k]
 RSA.generate=generate;RSA.import_key=import_key;DSA.generate=dsa_generate

def module(code):
 m=types.ModuleType('structured_answer');m.__file__=str(ROOT/'test_variant.py')
 exec(compile(code,m.__file__,'exec'),m.__dict__);return m

def scenario(m):
 with tempfile.TemporaryDirectory(prefix='structured-test-') as temp,contextlib.redirect_stdout(io.StringIO()) as output:
  m.DATA_DIR=Path(temp)/'state';m.setup();m.ROLE='client'
  for rid,desc,amount in [('G001','Lab equipment',500),('G002','Field travel',700)]:
   with patch('builtins.input',side_effect=[rid,desc,str(amount)]):assert m.submit()==rid
  assert m.view()==['G001','G002']
  saved=m.DATA_DIR/('records.'+m.CONFIG['storage'])
  assert saved.exists() and not b'Lab equipment' in saved.read_bytes() and not b'Field travel' in saved.read_bytes()
  with patch('builtins.input',side_effect=['G001','duplicate','2']):
   try:m.submit();raise AssertionError('duplicate accepted')
   except ValueError:pass
  with patch('builtins.input',side_effect=['G003','invalid','-1']):
   try:m.submit();raise AssertionError('negative accepted')
   except ValueError:pass
  m.ROLE='review'
  with patch('builtins.input',side_effect=['G001']):assert m.verify_action()
  with patch('builtins.input',side_effect=['G002']):assert m.search()=='G002'
  with patch('builtins.input',side_effect=['G001']):assert m.hex_view().hex()=='4c61622065717569706d656e74'
  with patch('builtins.input',side_effect=['G002']):assert m.hex_view().hex()=='4669656c642074726176656c'
  original=m.STATE['records']['G001'];broken=copy.deepcopy(original);broken['ct']='00'+broken['ct'][2:];m.STATE['records']['G001']=broken
  try:m.verified_record('G001');raise AssertionError('tampered description accepted')
  except ValueError:pass
  m.STATE['records']['G001']=original
  broken=copy.deepcopy(original);broken['signature']=[1,1] if isinstance(broken['signature'],list) else '00'*(len(broken['signature'])//2)
  m.STATE['records']['G001']=broken
  try:m.verified_record('G001');raise AssertionError('tampered signature accepted')
  except ValueError:pass
  m.STATE['records']['G001']=original
  try:m.submit();raise AssertionError('wrong role accepted')
  except ValueError:pass
  m.ROLE='finance'
  with patch('builtins.input',side_effect=['G001']):
   try:m.aggregate();raise AssertionError('single record aggregate accepted')
   except ValueError:pass
  with patch('builtins.input',side_effect=['G001, G002']):m.aggregate()
  assert m.STATE['aggregate']['ct']<m.PUBLIC['he']['n']**2
  assert m.finalize()==1200 and m.STATE['aggregate'] is None
  code=compile((ROOT/'template.py.txt').read_text().replace('@@CONFIG@@',repr(m.CONFIG)),'<second instance>','exec')
  restored=types.ModuleType('restored');restored.__file__=str(ROOT/'restart.py');exec(code,restored.__dict__)
  restored.DATA_DIR=m.DATA_DIR;restored.setup();restored.ROLE='client';assert restored.view()==['G001','G002']
  restored.ROLE='review'
  with patch('builtins.input',side_effect=['G001']):assert restored.search()=='G001'
  with patch('builtins.input',side_effect=['G001']):assert restored.verify_action()
  assert 'aggregate decrypted = 1200' in output.getvalue()
  assert 'Individual amounts not decrypted' in output.getvalue()
 return True

def case(row):
 try:
  code=(ROOT/row['path']).read_text();assert hashlib.sha256(code.encode()).hexdigest()==row['sha256']
  ast.parse(code);m=module(code);scenario(m);return row['path'],'PASS',None
 except Exception:return row['path'],'FAIL',traceback.format_exc()

def main():
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--workers',type=int,default=4);p.add_argument('--quick',action='store_true');args=p.parse_args()
 rows=list(csv.DictReader((ROOT/'MANIFEST.csv').open()));tested=rows[:12] if args.quick else rows;start=time.time();out=[]
 with multiprocessing.Pool(args.workers,initializer=init) as pool:
  for i,result in enumerate(pool.imap_unordered(case,tested,chunksize=8),1):
   out.append(result)
   if i%100==0 or result[1]=='FAIL':print(i,'/',len(tested),'fails',sum(r[1]=='FAIL' for r in out),flush=True)
 results={p:status for p,status,_ in out};fail=[dict(path=p,error=err) for p,status,err in out if status=='FAIL']
 if not args.quick:
  for row in rows:row['test_result']=results[row['path']]
  with (ROOT/'MANIFEST.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
 report=dict(total=len(rows),executed=len(out),passed=len(out)-len(fail),failed=len(fail),seconds=round(time.time()-start,2),failures=fail)
 (ROOT/'results.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k!='failures'},flush=True)
 for f in fail[:8]:print(f,flush=True)
 return int(bool(fail))
if __name__=='__main__':raise SystemExit(main())
