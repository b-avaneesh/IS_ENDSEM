"""Behavioral checks across stories and crypto axes for new operation answers."""
import contextlib,csv,io,json,sys,tempfile,traceback
from pathlib import Path
from unittest.mock import patch

HERE=Path(__file__).resolve().parent
ROOT=HERE if (HERE/'engine.py').exists() else HERE/'ENDSEM_MANUAL_PACK'
sys.path.insert(0,str(ROOT))
import legacy_test_helpers as helper

def run(row):
    m=helper.module((ROOT/row['path']).read_text())
    op=row['operation'];family=row['family']
    with tempfile.TemporaryDirectory(prefix='operation-test-') as folder,contextlib.redirect_stdout(io.StringIO()) as output:
        m.DATA_DIR=Path(folder)/'state'
        if family=='Voting_Style':
            m.FAST=True;m.rsa_key=lambda label,bits:helper.cached_rsa(m,label,bits)
        m.setup()
        if family=='Grant_Style':
            m.ROLE='client'
            for rid,value in [('A1',500 if op=='scalar' else 7),('A2',700 if op=='scalar' else 3)]:
                with patch('builtins.input',side_effect=[rid,'private text',str(value)]):m.submit()
            m.ROLE='review';m.verified_record('A1');m.verified_record('A2')
            with patch('builtins.input',side_effect=['A1']):assert m.hex_view()==b'private text'
            m.ROLE='finance'
            with patch('builtins.input',side_effect=['A1, A2']):m.aggregate()
            result=m.finalize();expected=2400 if op=='scalar' else 21
            assert result==expected,(result,expected)
            assert 'Individual' in output.getvalue()
            m.STATE={};m.setup();assert list(m.STATE['records'])==['A1','A2']
        else:
            users=list(m.GROUPS)
            for i,value in enumerate((2,3)):
                helper.action(m,'cast','client',[users[i],str(value),str(m.GROUPS[users[i]])])
                helper.action(m,'check','server',[str(i+1)])
            helper.action(m,'aggregate','tally',['1 2'])
            actual=helper.action(m,'decrypt_total','tally',['1 2','123','123'])[0]
            assert actual==(10 if op=='scalar' else 6),actual
            saved=m.STATE.copy();m.STATE={};m.setup();assert len(m.STATE['records'])==len(saved['records'])==2
    return True

def main():
    manifest=ROOT/'OPERATION_MANIFEST.csv';rows=list(csv.DictReader(manifest.open()))
    # Every story/operation, plus rotating cipher/hash/signature profiles.
    selected={}
    for row in rows:
        if row['cipher'] in ('aes192_cbc','aes256_cbc') and row['hash'] in ('md5','sha512') and row['sig'] in ('rsa_v15','elgamal'):
            selected.setdefault((row['family'],row['story'],row['operation']),row)
    ciphers=sorted({r['cipher'] for r in rows})
    profiles=[('sha256','ecdsa'),('sha512','dsa'),('sha3_256','schnorr'),('md5','rsa_pss'),('sha1','elgamal')]
    for i,cipher in enumerate(ciphers):
        h,s=profiles[i%len(profiles)]
        for family in ('Grant_Style','Voting_Style'):
            op=('rsa_product','elgamal_product','scalar')[i%3]
            row=next(r for r in rows if r['family']==family and r['story']==('01_grant' if family=='Grant_Style' else '01_voting')
                     and r['operation']==op and r['cipher']==cipher and r['hash']==h and r['sig']==s)
            selected[(family,row['story'],op,cipher)]=row
    fails=[];passed=[]
    for row in selected.values():
        try:run(row);passed.append(row['path'])
        except Exception:fails.append({'path':row['path'],'error':traceback.format_exc()})
    for row in rows:row['test_result']='PASS' if row['path'] in passed else 'SYNTAX PASS'
    if not fails:
        with manifest.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    report={'generated':len(rows),'behavioral_passed':len(passed),'behavioral_failed':len(fails),
            'other_syntax_passed':len(rows)-len(passed),'failures':fails}
    (ROOT/'OPERATION_TEST_RESULTS.json').write_text(json.dumps(report,indent=2))
    print({k:v for k,v in report.items() if k!='failures'},flush=True)
    for f in fails[:3]:print(f,flush=True)
    return bool(fails)
if __name__=='__main__':raise SystemExit(main())
