"""Enumerate compatible configurations; generate only an explicitly limited batch.
The complete space is 13,478,400 configurations, not shipped files or tested claims.
Example: python make_batch.py --skin voting --keywrap rabin --limit 20 --out my_batch
"""
import argparse,itertools,json,hashlib
from pathlib import Path
from engine import AXES,valid,render

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for axis,values in AXES.items():p.add_argument('--'+axis,choices=values)
    p.add_argument('--limit',type=int,default=20);p.add_argument('--count',action='store_true');p.add_argument('--out',type=Path,default=Path('generated_batch'));args=p.parse_args()
    choices={k:([getattr(args,k)] if getattr(args,k) else v) for k,v in AXES.items()}
    # Count factorized constraints rather than constructing 13 million dictionaries.
    hashes=sum(valid({**{k:v[0] for k,v in AXES.items()},'hash':h,'sig':s})[0] for h,s in itertools.product(choices['hash'],choices['sig']))
    tally=sum(valid({**{k:v[0] for k,v in AXES.items()},'he':h,'tally':t})[0] for h,t in itertools.product(choices['he'],choices['tally']))
    count=hashes*tally
    for axis in choices:
        if axis not in ('hash','sig','he','tally'):count*=len(choices[axis])
    print('Compatible configurations:',count)
    if args.count:return
    if args.limit<1:p.error('--limit must be positive')
    args.out.mkdir(parents=True,exist_ok=True);written=0;index=[]
    for values in itertools.product(*choices.values()):
        config=dict(zip(choices,values))
        if not valid(config)[0]:continue
        tag=hashlib.sha256(json.dumps(config,sort_keys=True).encode()).hexdigest()[:16];name=f'{config["skin"]}_{config["cipher"]}_{config["hash"]}_{config["sig"]}_{tag}.py'
        code=render(**config);path=args.out/name
        if path.exists() and path.read_text()!=code:raise FileExistsError(path)
        path.write_text(code,encoding='utf-8');index.append(dict(path=name,**config,test_result='NOT RUN'));written+=1
        if written>=args.limit:break
    (args.out/'batch_index.json').write_text(json.dumps(index,indent=2));print('Written:',written,'to',args.out)
if __name__=='__main__':main()
