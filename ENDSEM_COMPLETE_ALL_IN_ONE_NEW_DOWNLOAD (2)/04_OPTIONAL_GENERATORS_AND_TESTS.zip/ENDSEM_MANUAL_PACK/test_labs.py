"""Independent manual exercises: known vectors, crypto round-trips, actual TCP,
actual GnuPG, file sizes up to 10 MiB, failure cases and PCAP checksums.
Run from the pack root; no messages leave this machine.
"""
import ast,contextlib,importlib,io,json,sys,tempfile,time,traceback
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'lab_exercises'))
RESULTS=[]
def run(name,call):
    start=time.time()
    try:
        output=call();RESULTS.append(dict(case=name,status='PASS',seconds=round(time.time()-start,3),details=output));print(name,'PASS',flush=True)
    except Exception:
        RESULTS.append(dict(case=name,status='FAIL',error=traceback.format_exc()));print(name,'FAIL',RESULTS[-1]['error'],flush=True)

def main():
    for name in ('classical_ciphers','aes_round_trace','access_control_models','searchable_documents','key_management','bgn_toy_pairing','secp256k1_demo','homomorphic_workbench'):
        run(name,lambda name=name:importlib.import_module(name).self_test())
    import socket_integrity_signatures,gnupg_demo,snort_offline,asymmetric_workbench as a,hash_workbench as h,benchmarks
    run('TCP_10_cases',socket_integrity_signatures.local_demo)
    try:
        value=gnupg_demo.demo();RESULTS.append(dict(case='GnuPG_real_encrypt_sign_verify_tamper',status='PASS',details=value))
    except RuntimeError as e:
        if 'No agent running' not in str(e):raise
        RESULTS.append(dict(case='GnuPG_real_encrypt_sign_verify_tamper',status='BLOCKED',reason='gpg-agent cannot create Unix sockets in this execution environment. Source is provided; real GnuPG flow is not verified here.'))
        print('GnuPG BLOCKED: agent Unix sockets prohibited',flush=True)
    import symmetric_manual,cryptanalysis
    run('Manual_symmetric_inputs_and_invalid_keys',symmetric_manual.examples)
    def attacks():
        assert cryptanalysis.caesar_attack()=='TREASUSE' and cryptanalysis.weak_rsa()==173
        assert cryptanalysis.affine_attack()[0][:2]==(5,6)
        try:cryptanalysis.recover_permutation('ABCDEFGHI','CABDEHFGL');raise AssertionError('Invalid permutation accepted')
        except ValueError:pass
        return {'shift_key':4,'affine_key':[5,6],'invalid_manual_permutation_rejected':True}
    run('Classical_attacks_and_weak_RSA',attacks)
    def pcaps():
        with tempfile.TemporaryDirectory() as folder:return snort_offline.inspect(snort_offline.generate(folder))
    run('Snort_PCAP_checksums_only',pcaps)
    def asym():
        assert a.rsa_text('Asymmetric Encryption')[1]=='Asymmetric Encryption';r=a.elgamal_text('Confidential Data');assert r['plaintext']=='Confidential Data'
        assert a.ec_elgamal('abc')['plaintext']=='abc' and a.ecc_hybrid('Secure Transactions')['plaintext']=='Secure Transactions'
        assert a.rabin_demo(42)['original'] in a.rabin_demo(42)['four_possible_roots'];a.dh_demo();return {'manual_ElGamal_key_consistent':r['manual_key_consistent'],'computed_h':r['computed_h']}
    run('Asymmetric_manual_arithmetic',asym)
    def hashes():
        assert h.djb2('')==5381 and h.djb2('abc')==193485963
        assert h.hashes('abc')['sha256']=='ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad';return h.benchmark()
    run('Hash_vectors_and_100_strings',hashes)
    def symmetric():
        rows=benchmarks.symmetric(3);assert len(rows)==125;benchmarks.save(rows,ROOT/'tests/symmetric_benchmark');return {'configurations':25,'messages_per_configuration':5}
    run('Symmetric_125_roundtrips',symmetric)
    def files():
        rows=[]
        for kind in ('rsa','ecc'):
            for size in (1024,10240,1048576,10485760):rows.append(benchmarks.hybrid(kind,size))
        for kind in ('elgamal','rabin'):
            for size in (1024,10240):rows.append(benchmarks.hybrid(kind,size))
        benchmarks.save(rows,ROOT/'tests/asymmetric_benchmark');return rows
    run('Hybrid_12_file_roundtrips_up_to_10MiB',files)
    for path in sorted((ROOT/'lab_exercises').glob('*.py')):
        run('syntax_'+path.name,lambda path=path:bool(ast.parse(path.read_text())))
    report=dict(passed=sum(r['status']=='PASS' for r in RESULTS),failed=sum(r['status']=='FAIL' for r in RESULTS),blocked=sum(r['status']=='BLOCKED' for r in RESULTS),snort_engine='NOT RUN: executable absent',results=RESULTS)
    (ROOT/'tests/manual_results.json').write_text(json.dumps(report,indent=2,default=str));print('Manual tests:',report['passed'],'PASS',report['failed'],'FAIL')
    return bool(report['failed'])
if __name__=='__main__':raise SystemExit(main())
