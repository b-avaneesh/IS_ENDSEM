"""Generate 6,993 unique standalone endsem configurations and primitive demos."""
import csv,hashlib,itertools,subprocess,sys
from pathlib import Path
from engine import ROOT,SKINS,DEFAULT,AXES,valid,render
from demo_templates import generate
FIELDS=['path','group',*AXES,'line_count','sha256','test_result']
def configurations():
    seen=set()
    for skin in SKINS:
        for cipher,h,sig in itertools.product(AXES['cipher'],AXES['hash'],AXES['sig']):
            c=DEFAULT|dict(skin=skin,cipher=cipher,hash=h,sig=sig)
            if not valid(c)[0]:continue
            seen.add(tuple(c.values()));yield 'core',c
        for wrap,(he,tally),threshold,sse in itertools.product(AXES['keywrap'],[('paillier','sample'),('paillier','onehot'),('elgamal','product'),('rsa','product')],AXES['threshold'],AXES['sse']):
            c=DEFAULT|dict(skin=skin,keywrap=wrap,he=he,tally=tally,threshold=threshold,sse=sse)
            if tuple(c.values()) in seen:continue
            seen.add(tuple(c.values()));yield 'advanced',c

def main():
    rows=[]
    for group,c in configurations():
        skin_number=list(SKINS).index(c['skin'])+1
        if group=='core':rel=Path('tier_a')/f'{skin_number:02}_{c["skin"]}'/'core'/c['cipher']/c['hash']/f'{c["sig"]}.py'
        else:rel=Path('tier_a')/f'{skin_number:02}_{c["skin"]}'/'advanced'/c['keywrap']/f'{c["he"]}_{c["tally"]}_{c["threshold"]}_{c["sse"]}.py'
        code=render(**c);(ROOT/rel).parent.mkdir(parents=True,exist_ok=True);(ROOT/rel).write_text(code,encoding='utf-8')
        rows.append(dict(path=rel.as_posix(),group=group,**c,line_count=len(code.splitlines()),sha256=hashlib.sha256(code.encode()).hexdigest(),test_result='NOT RUN'))
    (ROOT/'Sample_QP_Answer.py').write_text(render(),encoding='utf-8')
    (ROOT/'primitive_demos').mkdir(exist_ok=True)
    for name,code in generate().items():(ROOT/'primitive_demos'/name).write_text(code,encoding='utf-8')
    with (ROOT/'MANIFEST.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=FIELDS);w.writeheader();w.writerows(rows)
    assert len(rows)==6993
    print('Generated',len(rows),'standalone endsem variants + 7 primitive demos.')
    subprocess.run([sys.executable,str(ROOT/'structured_records/build_all.py')],check=True)
    subprocess.run([sys.executable,str(ROOT/'structured_records/make.py'),'--skin','grant','--cipher','aes192_cbc','--hash','md5','--sig','rsa_v15','--output',str(ROOT/'Grant_Expense_Portal_Answer.py')],check=True)
if __name__=='__main__':main()
