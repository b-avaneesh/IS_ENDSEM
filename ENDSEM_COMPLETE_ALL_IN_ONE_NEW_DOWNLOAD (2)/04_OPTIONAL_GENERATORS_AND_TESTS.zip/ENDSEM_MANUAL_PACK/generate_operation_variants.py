"""Generate complete Lab 7 product/scalar answers for every shipped core profile."""
import ast,csv,hashlib,importlib.util,re,sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
ROOT=HERE if (HERE/'engine.py').exists() else HERE/'ENDSEM_MANUAL_PACK'
sys.path.insert(0,str(ROOT))
import engine as voting
spec=importlib.util.spec_from_file_location('structured_engine',ROOT/'structured_records/engine.py')
structured=importlib.util.module_from_spec(spec);spec.loader.exec_module(structured)
DEST=ROOT/'operation_variants'

def once(code,old,new):
    count=code.count(old)
    if count!=1:raise AssertionError((count,old[:95]))
    return code.replace(old,new,1)

def grant(code,operation):
    # Derive from the tested structured-record program; keep its role menus,
    # signatures, index, persistence, and encrypted description intact.
    end=code.index('"""',3)+3
    overview=('Paillier scalar multiplication of an encrypted combined sum'
              if operation=='scalar' else
              'textbook RSA modular product' if operation=='rsa_product' else
              'ElGamal modular product')
    header=('"""STRUCTURED-RECORD ENDSEM OPERATION VARIANT. Python 3.10+, PyCryptodome.\n'
            'Operation: '+overview+'. Exact cipher, hash, signature and story are in CONFIG.\n'
            'The description is encrypted separately; the signed record includes the encrypted value.\n'
            'Reviewer verifies the record and may display the decrypted DESCRIPTION in hex.\n'
            'Finance verifies selected records, combines their encrypted values and decrypts\n'
            'only the combined result (minimum two records); individual values stay encrypted.\n'
            'DEMO uses small numbers for a hand-checkable lab exercise; REAL uses large keys.\n'
            'Roles are local menu permissions, not separate machines. No encrypted comparison.\n'
            'Edit CONFIG/limits and use a fresh filename for a fresh persistent state folder.\n'
            '"""')
    code=header+code[end:]
    if operation=='scalar':
        code=once(code,'MAX_AMOUNT=1000 if DEMO_MODE else 10**9',
                  'MAX_AMOUNT=700 if DEMO_MODE else 10**9')
        code=once(code,'MAX_SELECTIONS=3 if DEMO_MODE else 100',
                  'MAX_SELECTIONS=2 if DEMO_MODE else 100\nSCALAR_FACTOR=2  # E(m)^k = E(k*m); fresh state after changing k.')
        code=once(code,"require(len(ids)*MAX_AMOUNT<PUBLIC['he']['n'],'Configured maximum possible sum exceeds Paillier modulus.')",
                  "require(len(ids)*MAX_AMOUNT*SCALAR_FACTOR<PUBLIC['he']['n'],'Scaled sum could wrap modulo n.')")
        code=once(code,'combined=math.prod(ciphertexts)%(PUBLIC[\'he\'][\'n\']**2)',
                  "combined=pow(math.prod(ciphertexts)%(PUBLIC['he']['n']**2),SCALAR_FACTOR,PUBLIC['he']['n']**2)")
        code=once(code,"require(math.prod(values)%(n*n)==current['ct'],'Aggregate ciphertext modified.')",
                  "require(pow(math.prod(values)%(n*n),SCALAR_FACTOR,n*n)==current['ct'],'Scaled aggregate ciphertext modified.')")
        code=once(code,"'total':'Output: Signatures valid; aggregate decrypted = {value}'",
                  "'total':'Output: Signatures valid; scaled aggregate decrypted = {value}'")
        code=once(code,"'product':'Output: Product of Paillier ciphertexts mod n^2 = {value}'",
                  "'product':'Output: Paillier aggregate raised to public scalar 2 = {value}'")
        code=once(code,'# aggregate() combines ciphertexts; finalize() decrypts only the total.',
                  '# aggregate() raises the combined ciphertext; finalize() decrypts only the scaled total.')
        return code

    kind='rsa' if operation=='rsa_product' else 'elgamal'
    crypto='''
# Raw RSA or ElGamal multiplication is modulo n/p. No OAEP here: OAEP does
# not preserve this property. The signing key is separate from this HE key.
HE_KIND='@KIND@'
def he_setup():
    if HE_KIND=='rsa':
        if DEMO_MODE:p,q=53,59
        else:
            while True:
                p,q=getPrime(1024),getPrime(1024)
                if p!=q and math.gcd(65537,math.lcm(p-1,q-1))==1:break
        n=p*q;d=pow(65537,-1,math.lcm(p-1,q-1))
        save_key('finance','product',d)
        return {'n':n,'e':65537}
    n=467 if DEMO_MODE else RFC_P
    secret=127 if DEMO_MODE else secrets.randbelow(n-3)+2
    save_key('finance','product',secret)
    return {'n':n,'g':2,'y':pow(2,secret,n)}
def he_encrypt(amount,record_id):
    h=PUBLIC['he'];n=h['n']
    require(0<=amount<n and (HE_KIND=='rsa' or amount>0),'Value outside multiplicative plaintext range.')
    if HE_KIND=='rsa':return pow(amount,h['e'],n)
    k=int.from_bytes(rng('he-'+record_id)(2*(n.bit_length()//8+1)),'big')%(n-2)+1
    return [pow(h['g'],k,n),amount*pow(h['y'],k,n)%n]
def he_combine(ciphertexts):
    n=PUBLIC['he']['n']
    if HE_KIND=='rsa':return math.prod(ciphertexts)%n
    return [math.prod(c[0] for c in ciphertexts)%n,
            math.prod(c[1] for c in ciphertexts)%n]
def he_valid(ciphertext):
    n=PUBLIC['he']['n']
    if HE_KIND=='rsa':return type(ciphertext) is int and 0<=ciphertext<n
    return (isinstance(ciphertext,list) and len(ciphertext)==2
            and all(type(x) is int for x in ciphertext)
            and 0<ciphertext[0]<n and 0<=ciphertext[1]<n)
def he_display(ciphertext):
    return hex(ciphertext) if HE_KIND=='rsa' else [hex(x) for x in ciphertext]
def he_decrypt_aggregate(ciphertext):
    n=PUBLIC['he']['n'];secret=load_key('finance','product')
    if HE_KIND=='rsa':return pow(ciphertext,secret,n)
    return ciphertext[1]*pow(pow(ciphertext[0],secret,n),-1,n)%n
'''.replace('@KIND@',kind)
    start=code.index('def he_setup():');end=code.index('def signer_setup():')
    code=code[:start]+crypto+code[end:]
    code=once(code,'MAX_AMOUNT=1000 if DEMO_MODE else 10**9',
              'MAX_AMOUNT=20 if DEMO_MODE else 10**9')
    code=once(code,'MAX_SELECTIONS=3 if DEMO_MODE else 100',
              'MAX_SELECTIONS=2 if DEMO_MODE else 100')
    code=once(code,"require(0<=record['amount_ct']<PUBLIC['he']['n']**2,'Invalid Paillier ciphertext.')",
              "require(he_valid(record['amount_ct']),'Invalid product ciphertext.')")
    code=once(code,"require(0<=value<=MAX_AMOUNT,'Amount outside configured range.')",
              "require((0 if HE_KIND=='rsa' else 1)<=value<=MAX_AMOUNT,'Value outside configured range.')")
    code=once(code,"say('paillier',value=hex(amount_ct))",
              "say('paillier',value=he_display(amount_ct))")
    code=once(code,"he=hex(record['amount_ct'])",
              "he=he_display(record['amount_ct'])")
    code=once(code,"require(len(ids)*MAX_AMOUNT<PUBLIC['he']['n'],'Configured maximum possible sum exceeds Paillier modulus.')",
              "require(MAX_AMOUNT**len(ids)<PUBLIC['he']['n'],'Possible product could wrap modulo the modulus.')")
    code=once(code,"combined=math.prod(ciphertexts)%(PUBLIC['he']['n']**2)",
              'combined=he_combine(ciphertexts)')
    code=once(code,"say('product',value=hex(combined))",
              "say('product',value=he_display(combined))")
    code=once(code,"require(math.prod(values)%(n*n)==current['ct'],'Aggregate ciphertext modified.')",
              "require(he_combine(values)==current['ct'],'Aggregate ciphertext modified.')")
    code=once(code,"'paillier':'Output Paillier amount CT(hex): {value}'",
              "'paillier':'Output @LABEL@ value CT(hex): {value}'".replace('@LABEL@','RSA' if kind=='rsa' else 'ElGamal'))
    code=once(code,'| Paillier CT: {he} |','| Product CT: {he} |')
    code=once(code,"'product':'Output: Product of Paillier ciphertexts mod n^2 = {value}'",
              "'product':'Output: Combined product ciphertext = {value}'")
    code=once(code,"'total':'Output: Signatures valid; aggregate decrypted = {value}'",
              "'total':'Output: Signatures valid; product decrypted = {value}'")
    code=once(code,"'private':'Output: Individual amounts not decrypted'",
              "'private':'Output: Individual values not decrypted'")
    code=once(code,'# aggregate() combines ciphertexts; finalize() decrypts only the total.',
              '# aggregate() multiplies ciphertexts; finalize() decrypts only the modular product.')
    return code

def vote(code,operation):
    if operation!='scalar':return code
    code=once(code,"TALLY_MODE = 'SAMPLE_COMPAT'", "TALLY_MODE = 'SCALAR'")
    code=once(code,'MIN_AGGREGATE_SIZE = 2  # Prevent individual-record decryption through the aggregate menu.',
              'MIN_AGGREGATE_SIZE = 2  # Prevent individual-record decryption through the aggregate menu.\nSCALAR_FACTOR = 2  # E(total)^2 = E(2*total); choose a fresh state folder after editing.')
    code=once(code,'AUTHORITIES,VALUES,SEARCH_BUCKET_MINUTES,STORAGE,TSA_SIGNED',
              'AUTHORITIES,VALUES,SCALAR_FACTOR,SEARCH_BUCKET_MINUTES,STORAGE,TSA_SIGNED')
    code=once(code,'    return result\ndef he_part(c,share):',
              "    if TALLY_MODE=='SCALAR': result=[pow(c,SCALAR_FACTOR,n*n) for c in result]\n    return result\ndef he_part(c,share):")
    code=once(code,"require(limit<PUBLIC['he']['bound'],'value_range')",
              "require(limit*SCALAR_FACTOR<PUBLIC['he']['bound'],'value_range')")
    code=once(code,"'total': 'Output decrypted aggregate: {value}'",
              "'total': 'Output decrypted scaled aggregate: {value}'")
    code=once(code,'SAMPLE_COMPAT sums raw IDs; it counts votes only when EVERY value is 1.',
              'SCALAR multiplies the encrypted sum by public SCALAR_FACTOR; not a vote count.')
    return code

def main():
    rows=[]
    for family,manifest in [('Voting_Style',ROOT/'MANIFEST.csv'),
                            ('Grant_Style',ROOT/'structured_records/MANIFEST.csv')]:
        for row in csv.DictReader(manifest.open()):
            core=row.get('group',row.get('family'))=='core'
            if not core and family=='Voting_Style' and not(row['he']=='paillier' and row['tally']=='sample'):
                continue
            for operation in ('rsa_product','elgamal_product','scalar') if core or family=='Grant_Style' else ('scalar',):
                config={k:row[k] for k in ('skin','cipher','hash','sig')}
                if family=='Voting_Style':
                    if core:
                        config.update(he='paillier' if operation=='scalar' else 'rsa' if operation=='rsa_product' else 'elgamal',
                                      tally='sample' if operation=='scalar' else 'product')
                    else:config={k:row[k] for k in voting.AXES}
                    code=vote(voting.render(**config),operation)
                else:
                    if not core:config.update(storage=row['storage'],index=row['index'])
                    code=grant(structured.render(**config),operation)
                ast.parse(code)
                story=row['path'].split('/')[1]
                folder={'rsa_product':'03_PRODUCT_RSA','elgamal_product':'04_PRODUCT_ELGAMAL','scalar':'05_SCALAR_PAILLIER'}[operation]
                sub=(f"{row['cipher']}/{row['hash']}/{row['sig']}.py" if core else
                     'extra/'+(f"{row['storage']}_{row['index']}.py" if family=='Grant_Style' else
                               f"{row['keywrap']}_{row['threshold']}_{row['sse']}.py"))
                path=DEST/family/story/folder/sub;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(code)
                rows.append(dict(path=path.relative_to(ROOT).as_posix(),family=family,story=story,operation=operation,
                                 cipher=row['cipher'],hash=row['hash'],sig=row['sig'],sha256=hashlib.sha256(code.encode()).hexdigest(),test_result='NOT RUN'))
    with (ROOT/'OPERATION_MANIFEST.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
    print('Generated',len(rows),'product/scalar full-program variants.')
if __name__=='__main__':main()
